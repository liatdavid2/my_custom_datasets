# Image-Classification-Using-Vision-transformer
Image Classification Using Vision transformer from Scractch

### Steps to follow:

git clone https://github.com/AarohiSingla/Image-Classification-Using-Vision-transformer

Follow the video to understand the code: https://youtu.be/awyWND506NY

![v](https://github.com/AarohiSingla/Image-Classification-Using-Vision-transformer/assets/60029146/5e25d95a-bba8-4066-9304-d29185122c47)

![w](https://github.com/AarohiSingla/Image-Classification-Using-Vision-transformer/assets/60029146/1a72d231-f7e3-4a78-bb2c-99872c546fe1)
